import React from 'react';
import DemoPage from "../templates/DemoPage";

const Demo = () => {
    return (
        <DemoPage/>
    );
};

export default Demo;